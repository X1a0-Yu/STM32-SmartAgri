#ifndef BUZZER_H
#define BUZZER_H
#include "common.h"
void buzzer_init(void);
void buzzer_set(bit on);
#endif
