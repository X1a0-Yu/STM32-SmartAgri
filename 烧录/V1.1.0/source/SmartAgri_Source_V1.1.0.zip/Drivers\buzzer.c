#include "buzzer.h"
#include "board.h"
#include "board_config.h"
#include "system_tick.h"
static bit g_buzzer_on;
void buzzer_init(void){
 RCC->APB1ENR|=RCC_APB1ENR_TIM3EN;
 TIM3->CR1=0;
 TIM3->DIER=0;
 TIM3->SR=0;
 g_buzzer_on=0;
 gpio_write(BUZZER_PORT,BUZZER_PIN,0);
 gpio_config_output(BUZZER_PORT,BUZZER_PIN,0x2U);
}
void buzzer_set(bit on){
 if(on==g_buzzer_on)return;
 g_buzzer_on=on;
 if(on){
  TIM3->PSC=(SystemCoreClock/1000000U)-1U;
  TIM3->ARR=(1000000U/(2U*350U))-1U;
  TIM3->EGR=TIM_EGR_UG;
  TIM3->SR=0;
  TIM3->DIER=TIM_DIER_UIE;
  NVIC_EnableIRQ(TIM3_IRQn);
  TIM3->CR1=TIM_CR1_CEN;
 }else{
  TIM3->CR1=0;
  TIM3->DIER=0;
  TIM3->SR=0;
  gpio_write(BUZZER_PORT,BUZZER_PIN,0);
 }
}
void TIM3_IRQHandler(void){
 if(TIM3->SR & TIM_SR_UIF){
  TIM3->SR &= ~TIM_SR_UIF;
  if(g_buzzer_on) BUZZER_PORT->ODR ^= (1UL<<BUZZER_PIN);
 }
}
