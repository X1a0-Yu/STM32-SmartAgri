#ifndef VERSION_H
#define VERSION_H
#define FW_VERSION_MAJOR 1
#define FW_VERSION_MINOR 1
#define FW_VERSION_PATCH 0
#define FW_PROTOCOL_VERSION 2
#define FW_STRING "SmartAgri V1.1.0"
#endif
