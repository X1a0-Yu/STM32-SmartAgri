智慧农业 Web 控制平台

演示模式（无需硬件）：
  python run.py --demo

连接实物（使用板载 CH340 / USART1）：
  python run.py --port COM6 --baud 9600

浏览器地址：
  http://127.0.0.1:8000

API 文档：
  http://127.0.0.1:8000/docs

主要 API：
  GET  /api/v1/state
  GET  /api/v1/history
  PUT  /api/v1/thresholds
  PUT  /api/v1/controls/{pump|fan|lamp|beep}
  POST /api/v1/controls/auto
  GET  /api/v1/serial/ports
  POST /api/v1/serial/connect
  WS   /ws/live
