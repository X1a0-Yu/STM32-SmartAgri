from __future__ import annotations
import argparse, threading, time, webbrowser
import uvicorn
from smartagri.main import app,configure

def main():
    p=argparse.ArgumentParser(description="智慧农业 Web 控制平台")
    p.add_argument("--port",help="应用串口，例如 COM6")
    p.add_argument("--baud",type=int,default=9600)
    p.add_argument("--host",default="127.0.0.1")
    p.add_argument("--web-port",type=int,default=8000)
    p.add_argument("--demo",action="store_true",help="无需硬件的演示模式")
    p.add_argument("--no-browser",action="store_true")
    args=p.parse_args()
    configure(args.port,args.baud,args.demo or not args.port)
    url=f"http://{args.host}:{args.web_port}"
    if not args.no_browser:
        threading.Thread(target=lambda:(time.sleep(1.2),webbrowser.open(url)),daemon=True).start()
    print(f"智慧农场控制台: {url}")
    print(f"模式: {'演示' if args.demo or not args.port else args.port+' @ '+str(args.baud)}")
    uvicorn.run(app,host=args.host,port=args.web_port,log_level="info")
if __name__=="__main__":main()
