"""Smart agriculture dashboard package."""
