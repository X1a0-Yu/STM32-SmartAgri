from __future__ import annotations
from collections import deque
from datetime import datetime, timezone
import asyncio

def utcnow(): return datetime.now(timezone.utc).isoformat()

class StateStore:
    def __init__(self):
        self.telemetry=None; self.raw=""; self.received_at=None
        self.history=deque(maxlen=300)
        self.serial={"connected":False,"port":None,"error":None,"retries":0}
        self.subscribers=set()
    def update_telemetry(self, data, raw=""):
        self.telemetry=dict(data); self.raw=raw; self.received_at=utcnow()
        point={"received_at":self.received_at, **self.telemetry}; self.history.append(point)
    def snapshot(self):
        return {"telemetry":self.telemetry,"thresholds":self.thresholds(),"controls":self.controls(),"warnings":self.warnings(),"serial":self.serial,"received_at":self.received_at,"raw":self.raw}
    def thresholds(self):
        if not self.telemetry:return None
        t=self.telemetry;return {"temp_min":t["TMIN"],"temp_max":t["TMAX"],"humi_min":t["HMIN"],"humi_max":t["HMAX"],"air_max":t["AIRMAX"],"light_min":t["LMIN"],"soil_min":t["SMIN"]}
    def controls(self):
        if not self.telemetry:return None
        t=self.telemetry;out={}
        for name,prefix,field in (("pump","P","PUMP"),("fan","F","FAN"),("lamp","LAMP","LAMP"),("beep","B","BEEP")):
            out[name]={"active":bool(t[field]),"mode":{0:"auto",1:"off",2:"on"}.get(t.get(prefix+"MODE",0),"auto"),"remaining":t.get(prefix+"REM",0)}
        return out
    def warnings(self):
        if not self.serial["connected"]: return [{"code":"serial_disconnected","severity":"critical","label":"设备串口未连接"}]
        if not self.telemetry:return [{"code":"no_data","severity":"warning","label":"等待农场数据"}]
        t=self.telemetry;w=[]
        checks=((t["T"]>t["TMAX"],"temp_high","温度超过上限",t["T"],t["TMAX"]),(t["T"]<t["TMIN"],"temp_low","温度低于下限",t["T"],t["TMIN"]),(t["H"]>t["HMAX"],"humi_high","湿度超过上限",t["H"],t["HMAX"]),(t["H"]<t["HMIN"],"humi_low","湿度低于下限",t["H"],t["HMIN"]),(t["AIR"]>t["AIRMAX"],"air_high","空气质量异常",t["AIR"],t["AIRMAX"]),(t["LIGHT"]<t["LMIN"],"light_low","光照不足",t["LIGHT"],t["LMIN"]),(t["SOIL"]<t["SMIN"],"soil_low","土壤湿度不足",t["SOIL"],t["SMIN"]))
        for active,code,label,val,limit in checks:
            if active:w.append({"code":code,"severity":"warning","label":label,"value":val,"threshold":limit})
        if t.get("VALID",0)!=3:w.append({"code":"sensor_invalid","severity":"critical","label":"部分传感器数据无效"})
        return w
    async def broadcast(self, event):
        dead=[]
        for q in tuple(self.subscribers):
            try:
                if q.full(): q.get_nowait()
                q.put_nowait(event)
            except Exception: dead.append(q)
        for q in dead:self.subscribers.discard(q)
